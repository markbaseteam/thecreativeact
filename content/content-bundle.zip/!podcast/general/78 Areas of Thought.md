```dataview 
Table datein as Старт, dateread as Готово, status as Статус
From "book/chapters" 
Where contains(status, "reading") 
sort dateread desc
```


---
Everyone Is a Creator
Tuning In
The Source of Creativity
Awareness
The Vessel and the Filter
The Unseen
Look for Clues
Practice
Submerge (The Great Works)
Nature as Teacher
Nothing Is Static
Look Inward
Memories and the Subconscious
It’s Always There
Setting
Self-Doubt
Make It Up
Distraction
Collaboration
Intention
Rules
The Opposite Is True
Listening
Patience
Beginner’s Mind
Inspiration
Habits
Seeds
Experimentation
Try Everything
Crafting
Momentum
Point of View
Breaking the Sameness
Completion
The Abundant Mindset
The Experimenter and the Finisher
Temporary Rules
Greatness
Success
Connected Detachment (Possibility)
The Ecstatic
Point of Reference
Non-Competition
Essence
Apocrypha
Tuning Out (Undermining Voices)
Self-Awareness
Right Before Our Eyes
A Whisper Out of Time
Expect a Surprise
Great Expectations
Openness
Surrounding the Lightning Bolt
24/7 (Staying In It)
Spontaneity (Special Moments)
How to Choose
Shades and Degrees
Implications (Purpose)
Freedom
The Possessed
What Works for You (Believing)
Adaptation
Translation
Clean Slate
Context
The Energy (In the Work)
Ending to Start Anew (Regeneration)
Play
The Art Habit (Sangha)
The Prism of Self
Let It Be
Cooperation
The Sincerity Dilemma
The Gatekeeper
Why Make Art?
Harmony
What We Tell Ourselves