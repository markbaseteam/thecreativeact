---
tags: author
genre: 
---

Rick Rubin — девятикратный обладатель премии «Грэмми», включенный в список 100 самых влиятельных людей мира по версии журнала Time и самый успешный продюсер в любом жанре по версии журнала Rolling Stone.

Он сотрудничал с артистами от Тома Петти до Адель, от Джонни Кэша до Red Hot Chili Peppers, от Beastie Boys до Slayer, от Канье Уэста до Strokes и от System of a Down до Jay-Z.

```dataview 
TABLE title, dateread, status, rating 
From "_notes/!books" 
WHERE contains(author, "Rick Rubin") 
sort dateread desc
```
