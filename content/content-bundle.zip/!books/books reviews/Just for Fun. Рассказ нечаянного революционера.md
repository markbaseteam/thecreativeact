---
title: 
author: 
rating: 
category: 
publisher: 
publishdate: 2017-09-05
pages: 
cover: 
datein:
dateread: 
status: to read
---

#книги

История линуса Торвальдса 
[Just for Fun. Рассказ нечаянного революционера](https://habr.com/ru/post/68788/)

---
