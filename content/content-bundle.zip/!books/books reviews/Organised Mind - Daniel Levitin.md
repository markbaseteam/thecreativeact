---
title: 
author: 
rating: 
category: 
publisher: 
publishdate: 2017-09-05
pages: 
cover: 
datein:
dateread: 
status: to read
---

#книги 

Рекомендовал прочитать #andrew_altshuler (things for thought)

---
