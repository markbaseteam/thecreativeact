---
title: Consistency is key
---

Show up. Do the work. Be consistent.

Then go take a look at the [[Your first note|first note]].
