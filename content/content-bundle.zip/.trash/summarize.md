---
PromptInfo:
 promptId: summarize
 name: 🗞️ Summarize 
 description: select a content and it will be summarized.
 author: Noureddine
 tags: writing, thinking, learning
 version: 0.0.1
---
content: 
{{context}}
prompt:
summarize the content


