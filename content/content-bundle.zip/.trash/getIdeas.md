---
PromptInfo:
 promptId: getIdeas
 name: 💡BrainStorm Ideas
 description: Brainstorm idea about the context.
 author: Noureddine
 tags: ideas, writing
 version: 0.0.1
---
content: 
{{context}}
prompt:
brainstorm ideas about this content
