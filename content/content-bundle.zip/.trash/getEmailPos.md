---
PromptInfo:
 promptId: getEmailPos
 name: ✉️ Reply to Email positively 😄
 description: select the email and a positive reply will be generated
 author: Noureddine
 tags: communication, email
 version: 0.0.1
---
prompt:
reply to this email positively in professional way. 
email: 
{{context}}
reply: 
