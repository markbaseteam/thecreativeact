---
PromptInfo:
 promptId: getOutline
 name: 🗒️Generate Outline
 description: Select a title, an outline will be generated for You.
 required_values: title
 author: Noureddine
 tags: writing
 version: 0.0.1
---
title:
{{title}}
prompt:
write an outline for a blog for this title.
outline:
- 